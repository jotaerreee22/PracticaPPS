var express = require('express');
var router = express.Router();

// Datos simulados idénticos a tu app.js para rellenar la pantalla
let datosPrueba = {
    usuarioLogueado: { id: 2, email: 'user1@app.com', nombre: 'Carlos Hurtado', rol: 'user', grupo: 1, foto: 'default.png' },
    compañeros: [
        { id: 3, email: 'user2@app.com', nombre: 'Ana Gómez', rol: 'user', grupo: 1, foto: 'default.png' },
        { id: 4, email: 'user3@app.com', nombre: 'Juan Pérez', rol: 'user', grupo: 1, foto: 'default.png' }
    ],
    mensajes: [
        { remitenteNombre: 'Ana Gómez', texto: '¡Hola Carlos! ¿Pudiste revisar los estilos de la interfaz?' },
        { remitenteNombre: 'Carlos Hurtado', texto: '¡Hola Ana! En eso estoy, probando las pantallas con Pug.' }
    ]
};

/* REEMPLAZO: En vez de cargar el login, cargamos directamente el panel de usuario */
router.get('/', function(req, res, next) {
  res.render('dashboard', { 
    usuario: datosPrueba.usuarioLogueado, 
    compañeros: datosPrueba.compañeros, 
    mensajes: datosPrueba.mensajes 
  });
});

module.exports = router;
